﻿BEGIN
Insert into TblVendorEmployee
(userID,vendorID)
values
(1, 1)
END