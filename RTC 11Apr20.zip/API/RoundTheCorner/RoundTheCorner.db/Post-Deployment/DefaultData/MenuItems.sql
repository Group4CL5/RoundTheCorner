﻿BEGIN
Insert into TblMenuItem
(itemName, menuID, MenuSectionID, [description], picture, price)
values
('cookie', 1, 1, 'cookie monster loves this', 'cookie.jpeg', 2)
END