﻿BEGIN
Insert into TblOrder
(userID, vendorId, orderDate)
values
(1, 1, '2020-03-22')
END