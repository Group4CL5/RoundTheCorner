﻿BEGIN
Insert into TblMenuSection
(MenuID,DisplayOrderNum,MenuSectionName)
values
(1, 1,'Kosher')
END