﻿BEGIN
Insert into TblOrderItem
(menuItemId, price)
values
(1, 3)
END