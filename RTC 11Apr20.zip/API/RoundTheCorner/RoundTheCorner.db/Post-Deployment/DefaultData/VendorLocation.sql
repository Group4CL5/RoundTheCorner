﻿BEGIN
Insert into TblVendorLocation
(vendorId, [datetime],locationX,locationY)
values
(1, '2020-06-23', 3, 5)
END