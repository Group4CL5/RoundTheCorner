﻿Begin
Insert into TblCuisine
(CuisineName, VendorID, MenuID)
Values 
('Dominican', 1, 1)
End