﻿BEGIN
Insert into TblMenu
(vendorID, isActive)
values
(1, 1)
END