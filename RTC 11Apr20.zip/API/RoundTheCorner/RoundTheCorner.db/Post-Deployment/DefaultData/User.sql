﻿BEGIN
Insert into TblUser
(firstName,lastName,phone,email,[password],DOB, deactivated)
values
('Conner','Hando','123456789','Conner.hando@student.com','loopmaker123','1997-09-11', 0)
END