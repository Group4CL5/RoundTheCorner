﻿BEGIN
Insert into TblReview
(VendorID, UserID,Rating,[Subject],Body)
values
(1, 1,4,'It was not the best', 'I wish that they cooked the steak a little less')
END