﻿BEGIN
Insert into TblVendor
(CompanyEmail, CompanyName, inspectionDate, LicenseNumber, OwnerID, Website, bio)
values
('company@email.com', 'TopCorp','2020-04-11',123456, 1,'TopCorp.com','Were the best and no one tops us' )
END