﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoundTheCorner.BL.Models
{
    public class VendorEmployeeModel
    {
        public int ID { get; set; }
        public int UserID { get; set; }

        public int VendorID {get;set;}
    }
}
