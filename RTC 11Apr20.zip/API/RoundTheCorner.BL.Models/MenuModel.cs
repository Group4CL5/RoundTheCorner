﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace RoundTheCorner.BL.Models
{
    public class MenuModel
    {
        public int MenuID { get; set; }
        public int VendorID { get; set; }
        public bool IsActive { get; set; }

    }
}
